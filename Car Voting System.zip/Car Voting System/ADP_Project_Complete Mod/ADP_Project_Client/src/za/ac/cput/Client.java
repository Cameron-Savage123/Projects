package za.ac.cput;

/**
 *
 * @author S
 */
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Client {

    protected static ObjectInputStream in;
    protected static ObjectOutputStream out;
    private List<DomainClass> vehicleData;
    private Socket socket;
    private ClientGui clientGui;

    public Client() {

        //Connect to the server
        try {

            socket = new Socket("127.0.0.1", 6666);
            System.out.println("Connected To Server");
            getStreams();

        } catch (IOException ioe) {
            System.out.println("IOException: " + ioe.getMessage());

        }
    }

    private void getStreams() {
        //Making da pathways
        try {

            out = new ObjectOutputStream(socket.getOutputStream());
            System.out.println("Output Stream Client Side created");
            in = new ObjectInputStream(socket.getInputStream());
            System.out.println("Input Stream Client Side created");

        } catch (IOException ioe) {
            System.out.println("IOException: " + ioe.getMessage());
        }

    }

    public void communicate(String msg) {
        try {

            System.out.println("Sending request: " + msg);
            out.writeObject(msg);
            out.flush();

            // Read the response
            Object receivedData = in.readObject();

            if (receivedData instanceof List) {
                List<DomainClass> vehicleData = (List<DomainClass>) receivedData;
                System.out.println("Received updated vehicle data: " + vehicleData);
                ClientGui.instance.updateData(vehicleData); 
            } else {
                System.out.println("Unexpected input/data from server.");
                JOptionPane.showMessageDialog(null, "Could not process your input. Try again", "Data Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException ioe) {
            System.out.println("IOException: " + ioe.getMessage());
            JOptionPane.showMessageDialog(null, "IOException occurred. Please try again.", "Update Error", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException cnfe) {
            System.out.println("ClassNotFoundException: " + cnfe.getMessage());
            JOptionPane.showMessageDialog(null, "ClassNotFoundException occurred. Please try again.", "Update Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void closeConnection() {
        //Close Streams and Socket
        try {
            if (out != null) {
                out.close();
                System.out.println("Closing Output Stream");
            }
            if (in != null) {
                in.close();
                System.out.println("Closing Input Stream");
            }
            if (socket != null) {
                socket.close();
                System.out.println("Closing Socket");
            }
        } catch (IOException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }

}
