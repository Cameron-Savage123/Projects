package za.ac.cput;

import java.io.Serializable;

public class DomainClass implements Serializable {
    private static final long serialVersionUID = 123456789L;  // Use the same value on both sides

    private String vehicle_id;
    private String vehicle_name;
    private int vote_count;

    public DomainClass(String vehicle_id, String vehicle_name, int vote_count) {
        this.vehicle_id = vehicle_id;
        this.vehicle_name = vehicle_name;
        this.vote_count = vote_count;
    }

    // Getters and setters
    public String getVehicle_id() {
        return vehicle_id;
    }

    public void setVehicle_id(String vehicle_id) {
        this.vehicle_id = vehicle_id;
    }

    public String getVehicle_name() {
        return vehicle_name;
    }

    public void setVehicle_name(String vehicle_name) {
        this.vehicle_name = vehicle_name;
    }

    public int getVote_count() {
        return vote_count;
    }

    public void setVote_count(int vote_count) {
        this.vote_count = vote_count;
    }

    @Override
    public String toString() {
        return "DomainClass{" + "vehicle_id=" + vehicle_id + ", vehicle_name=" + vehicle_name + ", vote_count=" + vote_count + '}';
    }
}
