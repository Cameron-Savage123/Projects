package za.ac.cput;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import za.ac.cput.DomainClass;

/**
 *
 * @author S
 */
public class ClientGui extends JFrame {

    private JPanel topPanel, bottomPanel, centerPanel, addVehiclePnl;
    private JComboBox cmboVehicles;
    String[] listOfVehicles = {"select", "Ford Ranger", "Audi A3", "BMW X3", "Toyota Starlet", "Suzuki Swift"};
    private JButton voteBtn, viewVotesBtn, exitBtn, addVehicleBtn;
    private JTable votesTbl;
    DefaultTableModel votesTblMod;
    private JLabel vehicleLbl, titleLbl, addVehicleLbl;
    private JTextField addVehicleFld;
    Client clientObj = new Client();
    public static ClientGui instance;

    public ClientGui() {

        super("Car of The Year Voting System 2024");
        instance = this;
        titleLbl = new JLabel("Car of the Year");
        addVehicleLbl = new JLabel("Enter Vehicle Name: ");
        addVehicleFld = new JTextField(10);

        //Panels
        topPanel = new JPanel();
        bottomPanel = new JPanel(new GridBagLayout());
        centerPanel = new JPanel();
        addVehiclePnl = new JPanel(new GridBagLayout());

        //Table for displaying vehicle names and votes
        votesTblMod = new DefaultTableModel();
        votesTblMod.addColumn("Vehicle");
        votesTblMod.addColumn("Number of Votes");
        votesTbl = new JTable(votesTblMod);

        //Buttons
        voteBtn = new JButton("Vote");
        viewVotesBtn = new JButton("View Data");
        exitBtn = new JButton("Exit");
        addVehicleBtn = new JButton("Add Vehicle");

        //Combo Box of vehicles for voting
        vehicleLbl = new JLabel("Vehicle: ");
        cmboVehicles = new JComboBox(listOfVehicles);

    }

    public void setGUI() {
        //GUI Design      

        //Add components to the top panel
        titleLbl.setFont(new Font("Verdana", Font.BOLD, 30));
        titleLbl.setForeground(Color.WHITE);
        titleLbl.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        topPanel.setBackground(Color.BLACK);

        topPanel.add(titleLbl);
        topPanel.setPreferredSize(new Dimension(getWidth(), 100));

        //Add components to center panel
        centerPanel.add(vehicleLbl);
        centerPanel.add(cmboVehicles);

        //Add components to bottom panel
        bottomPanelLayout();

        //Add panels to frame
        this.add(topPanel, BorderLayout.NORTH);
        this.add(centerPanel, BorderLayout.CENTER);
        this.add(bottomPanel, BorderLayout.SOUTH);

        //Me when i add a vehicle to the database
        addVehicleBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAddVehicleDialog();

//                
            }
        });

        //Me when i vote(I live in a democratic society)
        voteBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("things are happening");
                String selectedVehicle = (String) cmboVehicles.getSelectedItem();
                if (!selectedVehicle.equals("select")) {
                    if (Client.out != null) {

                        sendData(selectedVehicle);
                        JOptionPane.showMessageDialog(null, "Your vote for " + selectedVehicle + " has been cast", "Vote Confirmation", JOptionPane.INFORMATION_MESSAGE);

                    } else {
                        System.out.println("Client output stream is null, not connected to the server.");
                        JOptionPane.showMessageDialog(null, "Not connected to the server. Please check the connection.", "Connection Error", JOptionPane.ERROR_MESSAGE);
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Please select a vehicle.", "Vehicle Selection Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        //Exiting and making sure the connection closes as well
        exitBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clientObj.closeConnection();
                System.exit(0);

            }
        });

        //Me when i wanna see how corrupt the country is
        viewVotesBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Communicate with the server to request updated data
                    clientObj.communicate("Request");

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

                }
            }
        });
    }

    //Method to send the vehicle a user voted for to the server
    private void sendData(String vehicleData) {
        try {

            System.out.println("Sending data to server: " + vehicleData);
            Client.out.writeObject(vehicleData);  // writing vehicle name/data to the server
            Client.out.flush();  // cleaning out channels 
            System.out.println(vehicleData + " has been recorded");
        } catch (IOException ioe) {
            System.out.println("IOException while sending data: " + ioe.getMessage());
            JOptionPane.showMessageDialog(null, "Error sending vote data to the server.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void updateData(List<DomainClass> vehicleData) {
        // Clear existing data in table and combo box
        votesTblMod.setRowCount(0);
        cmboVehicles.removeAllItems();

        // Populate table and combo box with updated data from the server
        for (DomainClass vehicle : vehicleData) {
            String vehicleName = vehicle.getVehicle_name();
            int vehicleVotes = vehicle.getVote_count();

            // Add each vehicle to the table (name and vote count)
            votesTblMod.addRow(new Object[]{vehicleName, vehicleVotes});

            // Add each vehicle to the combo box
            cmboVehicles.addItem(vehicleName);
        }

        // Add "select" option to the combo box
        cmboVehicles.insertItemAt("select", 0);
        cmboVehicles.setSelectedIndex(0); // make sure select option is first. user must open cmbo box to select a vehicle to vote for.
    }

    public void openAddVehicleDialog() {
        boolean getInput = false;

        while (!getInput) {

            addVehiclePnl.removeAll();
            GridBagConstraints gbc = new GridBagConstraints();


            gbc.gridx = 0; 
            gbc.gridy = 0; 
            gbc.anchor = GridBagConstraints.WEST; 
            addVehiclePnl.add(addVehicleLbl, gbc);

            gbc.gridx = 1; 
            addVehiclePnl.add(addVehicleFld, gbc); 


            gbc.gridx = 0; 
            gbc.gridy = 1; 
            gbc.gridwidth = 2; 
            gbc.anchor = GridBagConstraints.CENTER; 
            addVehiclePnl.add(new JLabel("NOTE: If the vehicle has already been entered, a vote will automatically be added."), gbc);


            int input = JOptionPane.showConfirmDialog(null, addVehiclePnl, "New Vehicle Entry", JOptionPane.OK_CANCEL_OPTION);
            if (input == JOptionPane.OK_OPTION) {

                if (addVehicleFld.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter a new vehicle to vote for", "Input Error", JOptionPane.ERROR_MESSAGE);

                } else {

                    sendData(addVehicleFld.getText());
                    JOptionPane.showMessageDialog(null, addVehicleFld.getText() + " has been entered", "Entry Confirmation", JOptionPane.INFORMATION_MESSAGE);
                    getInput = true;
                }
            } else {
                getInput = true;
            }

        }
        addVehicleFld.setText("");

    }

    public void bottomPanelLayout() {
        GridBagConstraints gbc = new GridBagConstraints();
        voteBtn.setBackground(Color.BLACK);
        voteBtn.setForeground(Color.WHITE);
        viewVotesBtn.setBackground(Color.BLACK);
        viewVotesBtn.setForeground(Color.WHITE);
        exitBtn.setBackground(Color.BLACK);
        exitBtn.setForeground(Color.WHITE);
        addVehicleBtn.setBackground(Color.BLACK);
        addVehicleBtn.setForeground(Color.WHITE);
        //padding
        gbc.insets = new Insets(5, 5, 5, 5);

        //set table
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        bottomPanel.add(new JScrollPane(votesTbl), gbc);

        //set buttons
        gbc.weightx = 0.25;
        gbc.weighty = 0;

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        bottomPanel.add(addVehicleBtn, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        bottomPanel.add(voteBtn, gbc);

        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        bottomPanel.add(viewVotesBtn, gbc);

        gbc.gridx = 3;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        bottomPanel.add(exitBtn, gbc);
    }

    public static void main(String args[]) {
        //construct a ClientGUI object and make it visible
        ClientGui cg = new ClientGui();
        cg.setLocation(600, 200);
        cg.pack();
        cg.setSize(850, 800);
        cg.setDefaultCloseOperation(EXIT_ON_CLOSE);
        cg.setGUI();
        cg.setVisible(true);

    }
}
