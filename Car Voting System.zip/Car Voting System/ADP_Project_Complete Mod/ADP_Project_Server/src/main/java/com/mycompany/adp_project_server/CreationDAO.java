/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.adp_project_server;

import za.ac.cput.DomainClass;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author camer
 */
public class CreationDAO {

    public void createTable() throws SQLException {
        String createVehicleStmt = "CREATE TABLE Vehicle(vehicle_id VARCHAR(30) PRIMARY KEY,vehicle_name VARCHAR(30),vote_count INTEGER    )  ";

        try (Connection con = DBConnection.getConnection()) {
           // con.setAutoCommit(true);
            DatabaseMetaData dbm = con.getMetaData();

            try (ResultSet rs = dbm.getTables(null, null, "Vehicle", null)) {
                if (!rs.next()) {
                    try (PreparedStatement ps = con.prepareStatement(createVehicleStmt)) {
                        ps.executeUpdate();
                    }
                }
            }

        }
    }

    public void insertVehicle(DomainClass domain) throws SQLException {
        String insertStmt = "INSERT INTO Vehicle (vehicle_id, vehicle_name,vote_count) VALUES (?, ?, ?)";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(insertStmt)) {
            ps.setString(1, domain.getVehicle_id());
            ps.setString(2, domain.getVehicle_name());
            ps.setInt(3, domain.getVote_count());
            ps.executeUpdate();
        }
    }

    public List<DomainClass> getAllVehicles() throws SQLException {
        String selectStmt = "SELECT * FROM Vehicle";
        List<DomainClass> vehicles = new ArrayList<>();
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(selectStmt); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String vehicle_id = rs.getString("vehicle_id");
                String vehicle_name = rs.getString("vehicle_name");
                int vote_count = rs.getInt("vote_count");
                vehicles.add(new DomainClass(vehicle_id, vehicle_name, vote_count));
            }
        }
        return vehicles;
    }

    public void deleteVehicle(String vehicle_id) throws SQLException {
        String deleteStmt = "DELETE FROM Vehicle WHERE vehicle_id=?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(deleteStmt)) {
            ps.setString(1, vehicle_id);
            ps.executeUpdate();
        }
    }

    public String getLatestVehicleId() throws SQLException {
        String latestId = null;
        String sql = "SELECT vehicle_id FROM Vehicle";  // SQL query to get all vehicle IDs

        try (Connection con = DBConnection.getConnection(); PreparedStatement stmt = con.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            // Loop through all rows and fetch the vehicle_id
            while (rs.next()) {
                String currentId = rs.getString("vehicle_id");

                // If latestId is null or the current ID is greater, update the latestId
                if (latestId == null || currentId.compareTo(latestId) > 0) {
                    latestId = currentId;  // Keep track of the highest vehicle ID
                }
            }
        } catch (SQLException e) {
            System.out.println("Error fetching the latest vehicle ID: " + e.getMessage());
            throw e;  // Thrown so the Server class can handle it
        }

        return latestId;  // Return the highest vehicle ID
    }

    public void incrementVoteCount(String vehicleId) throws SQLException {
        String updateStmt = "UPDATE Vehicle SET vote_count = vote_count + 1 WHERE vehicle_id = ?";

        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(updateStmt)) {
            ps.setString(1, vehicleId);
            ps.executeUpdate();
        }
    }

    public boolean vehicleExists(String vehicleName) throws SQLException {
        String query = "SELECT COUNT(*) FROM Vehicle WHERE vehicle_name = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, vehicleName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0; // Return true if the count is greater than 0
                }
            }
        }
        return false;
    }


    public String getVehicleIdByName(String vehicleName) throws SQLException {
        String query = "SELECT vehicle_id FROM Vehicle WHERE vehicle_name = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, vehicleName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("vehicle_id"); // Return the vehicle ID
                }
            }
        }
        throw new SQLException("Vehicle name not found: " + vehicleName); // Throw an exception if the vehicle is not found
    }

}
