package com.mycompany.adp_project_server;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class ServerGui extends JFrame implements ActionListener {

    private Server server; // Server instance
    private JButton exitBtn = new JButton("EXIT");
    private JTextArea clientTxtArea = new JTextArea(5, 40);
    private JPanel topPanel = new JPanel();
    private JPanel centerPanel = new JPanel();

    public ServerGui() {
        super("Voting Server");

        topPanel.add(new JScrollPane(clientTxtArea));
        centerPanel.add(exitBtn);
        add(topPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.SOUTH);

        clientTxtArea.setEditable(false);
        exitBtn.addActionListener(this);

        setSize(500, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        setLocation(50,50);
        setVisible(true);

        // Start the server
        server = new Server(this);
        server.start();
    }

    public void updateClientTextArea(String message) {
        clientTxtArea.append(message + "\n");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == exitBtn) {
            server.closeConnection();
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new ServerGui(); // Create the GUI
    }
}
